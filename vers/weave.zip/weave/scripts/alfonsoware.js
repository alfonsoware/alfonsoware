utils.play_sound("C:\\Windows\\Media\\Speech Disambiguation.wav");
// alfonso-ware SRC

// Loaded script
cheat.log("alfonso-ware.js successfully loaded");
cheat.log("por el phonn");

// VARS

const Renderlogs = function(txt) {
    cheat.print_to_console("[alfonso-ware] ", [vars.get_int("js.color_red"), vars.get_int("js.color_green"), vars.get_int("js.color_blue")]);
    cheat.print_to_console(txt + "\n", [255, 255, 255]);
}

var master_active = []
var global_alpha = 0
var width = 0
var lasttime = 0;

function lerp(a, b, c) {
	return a+(b-a) * c
}

function print(arg) {
	cheat.log(arg+"");
}

const KILLSAYS1 = [
	"ты реально надеялся меня убить?", "где мозги проебала шаболда",
	"гет гуд гет иди нахуй", 
	"легчайший для величайшего долбаёб))", "и че ты опять сделал?", "пулю поймал припиздок немощный",
	"by L3rezsync hvh boss", "бэктрэкед ту африка дегенерат))", "смерть преследует тебя немощ ебаный",
];

	const KILLSAYS2 = [
	"смерть преследует тебя немощ ебаный", "по зоологии вынюхал пидораса", "опять тапыч поймал мусор", "dont be loser, buy defuser",
	"нищ даже пройти спокойно не можешь", "ебать ты там орбиту улетел долбаёб))", "240KG PROFESSIONAL?",
	"кадык мне в зад вот это я зарядил тебе", "жри землю мышь", "игрок?", "в сон лети нахуй", "гвоздь мне в кеды что он вешает",
	"by Lerezsync hvh boss", "бошка взорвалась от моего наплыва", "бэктрэкед ту африка дегенерат))",
	"земля те землей пидорас ебаный))", "заглатывай овца", "съебала моча", 
];

var handle_binds = [
	["force_safepoints", "Safe points override"],
	["body_aim", "Force body aim"],
	["inverter", "Anti-aim inverter"],
	["fake_duck", "Duck peek assist"],
	["slow_walk", "Slow motion"],
	["doubletap", "Double tap"],
	["hide_shots", "On shot anti-aims"],
	["peek_assist", "Quick peek assist"],
	["override_damage", "Damage override  "],
]

// UI
ui.add_checkbox("Load default preset", "preset");
ui.add_slider("Style switcher", "styles_switcher", 1, 4);
ui.add_checkbox("Keybinds", "hotkeys_list");
ui.add_slider("Keybinds X", "kb_x", 50, 1780);
ui.add_slider("Keybinds Y", "kb_y", 50, 1050);
ui.add_checkbox("Watermark", "watermark");
ui.add_checkbox("Debug panel", "debug_panel");
ui.add_checkbox("Legs animations fucker", "animfucker");
ui.add_checkbox("Advanced double-tap", "advanced_dt");
ui.add_checkbox("Hit and hurt logs in console", "logs_cons");
ui.add_checkbox("Indicators under crosshair", "indicators");
ui.add_slider("Indicators under-cross style switcher", "inds_styles_switcher", 1, 2);
ui.add_checkbox("Manual arrows", "manual_arrows");
ui.add_checkbox("Trashtalk", "trashtalk");
ui.add_checkbox("Clantag", "clantag");
ui.add_checkbox("Clear clantag", "clear_tag");
ui.add_checkbox("Custom Hitsounds", "custom_hitsounds");
ui.add_slider("Hitsounds style switcher", "hitsounds_styles_switcher", 1, 3);
ui.add_slider("Color red", "color_red", 1, 255)
ui.add_slider("Color green", "color_green", 1, 255)
ui.add_slider("Color blue", "color_blue", 1, 255)
// Functional

register_callback("render", function () {
	if(vars.get_bool("js.debug_panel")) {

	var palette = {red: vars.get_int("js.color_red"), green: vars.get_int("js.color_green"), blue: vars.get_int("js.color_blue"), pulse: Math.sin(Math.abs(-3.14 + global_vars.curtime() * 1.555555555555555 % 6.28)) * 170}
	var switcher = vars.get_int("js.styles_switcher");
	     
	    render.text([50, 518], [255, 255, 255, 255], 8, 0, "» alfonsoware.tk"); render.text([140, 518], [palette.red, palette.green, palette.blue, 255], 8, 0, "beta")
	    render.text([50, 531], [255, 255, 255, 255], 8, 0, "» user:"); render.text([90, 531], [palette.red, palette.green, palette.blue, 255], 8, 0, "phon") // change user here || поменять пользователя тут
	    render.text([50, 544], [255, 255, 255, 255], 8, 0, "» build:"); render.text([92, 544], [palette.red, palette.green, palette.blue, 255], 8, 0, "alpha")

	        switch(switcher) {
		        case 1: render.rect([45, 515], [160, 45], [palette.red, palette.green, palette.blue, palette.pulse], 4); render.filled_rect([45, 515], [159, 45], [15, 15, 15, 35], 4); 
		    break;
		        case 2: render.rect([45, 515], [160, 45], [palette.red, palette.green, palette.blue, palette.pulse], 10); render.filled_rect([45, 515], [159, 45], [15, 15, 15, 35], 10); 
		    break;
			    case 3: render.rect([45, 515], [160, 1], [palette.red, palette.green, palette.blue, 170], 0); render.filled_rect([45, 515], [159, 45], [15, 15, 15, 35], 0); 
		    break;
		        case 4: render.rect([45, 515], [160, 45], [palette.red, palette.green, palette.blue, 170], 0); render.filled_rect([45, 515], [159, 45], [15, 15, 15, 35], 0); 
		    break;
	   }
    }
})

register_callback("createmove", function () {
	if(vars.get_bool("js.preset")) {
		vars.set_int("js.inds_styles_switcher", 0);
		vars.set_int("js.styles_switcher", 2);
		vars.set_int("js.kb_x", 430);
		vars.set_int("js.kb_y", 430);
		vars.set_int("js.hitsounds_styles_switcher", 3);
		vars.set_int("js.color_red", 100);
		vars.set_int("js.color_green", 155);
		vars.set_int("js.color_blue", 255);
		vars.set_bool("js.hotkeys_list", true);
		vars.set_bool("js.watermark", true);
		vars.set_bool("js.animfucker", true);
		vars.set_bool("js.logs_cons", true);
		vars.set_bool("js.indicators", true);
		vars.set_bool("js.manual_arrows", true);
		vars.set_bool("js.advanced_dt", true);
		vars.set_bool("js.debug_panel", true);
		vars.set_bool("js.custom_hitsounds", true);
		vars.set_bool("js.preset", false);
	}
})

register_callback("player_hurt", function () {
	if(vars.get_bool("js.custom_hitsounds")) {

    var user = entity.get_player_for_user_id(current_event.get_int("userid"))
    var attacker = entity.get_player_for_user_id(current_event.get_int("attacker"))
	switcher = vars.get_int("js.hitsounds_styles_switcher");

	    if (attacker == entity.get_local_player() && user != entity.get_local_player()) {
	    switch (switcher) {
	        case 1: utils.play_sound("C:\\half-life.js\\first_sound.wav");
		break;
		    case 2: utils.play_sound("C:\\half-life.js\\second_sound.wav");
		break;
		    case 3: utils.play_sound("C:\\half-life.js\\third_sound.wav");
		break;
		}
	}
}
});

register_callback("render", function () {
	const binds = { manual_left: vars.is_bind_active("manual_left"), manual_right: vars.is_bind_active("manual_right"), }
	var palette = {red: vars.get_int("js.color_red"), green: vars.get_int("js.color_green"), blue: vars.get_int("js.color_blue")}
	if (vars.get_bool("js.manual_arrows")) {
	render.text([980, 528], binds.manual_right ? [palette.red, palette.green, palette.blue, 255] : [255, 255, 255, 55], 8, 3, ">")
	render.text([925, 528], binds.manual_left ? [palette.red, palette.green, palette.blue, 255] : [255, 255, 255, 55], 8, 3, "<")
	}
})

register_callback("createmove", function() {
	if (vars.get_bool("js.advanced_dt")) {
	  convars.set_int("cl_clock_correction", 0);
	  convars.set_int("sv_maxusrcmdprocessticks", 18);
	} else {
	  convars.set_int("cl_clock_correction", 1);
	  convars.set_int("sv_maxusrcmdprocessticks", 16);
	}
  });

register_callback("player_hurt", function() {

    var user = entity.get_player_for_user_id(current_event.get_int("userid"))
    var attacker = entity.get_player_for_user_id(current_event.get_int("attacker"))

    var user_info = entity.get_player_info(user);
    var attacker_info = entity.get_player_info(attacker);

    var hitgroup = current_event.get_int("hitgroup");

    switch (hitgroup) {
    case 1: hitgroup = "head"; break;
    case 2: hitgroup = "chest"; break;
    case 3: hitgroup = "stomach"; break;
    case 4: hitgroup = "left arm"; break;
    case 5: hitgroup = "right arm"; break;
    case 6: hitgroup = "right leg"; break;
    case 7: hitgroup = "left leg"; break;
    default: hitgroup = "generic";
    }

    if (attacker == entity.get_local_player() && user != entity.get_local_player())
	    Renderlogs("Hurt in " + user_info.name + "'s " + hitgroup + " for " + current_event.get_int("dmg_health") + " damage");
	else if (user == entity.get_local_player() && attacker != entity.get_local_player())
	    Renderlogs(attacker_info.name + " hurt you in" + hitgroup + " for " + current_event.get_int("dmg_health") + " damage");
});


const get_active_binds = function() {
	var width = 15
	for (var i = 0; i < handle_binds.length; i++) {
		if(vars.is_bind_active(handle_binds[i][0])){
			if(!master_active[i]){
				master_active[i] = {data: handle_binds[i], alpha: 0, offset: 0};
			}
			master_active[i].alpha = Math.ceil(lerp(master_active[i].alpha, 255, 6 * global_vars.frametime()))
			master_active[i].offset = handle_binds[i][1].length
		} else {
			if (master_active[i]){
				master_active[i].alpha =  Math.floor(lerp(master_active[i].alpha, 0,6 * global_vars.frametime()))
				if (master_active[i].alpha == 0){
					master_active[i] = null
				}
			}
		}
        if(master_active[i] && master_active[i].offset > width){
            width = master_active[i].offset
        }
	}
	return [master_active, width]
}

register_callback("render", function() {
	if (vars.get_bool("js.hotkeys_list")) {
	var count = 0
	var y = vars.get_int("js.kb_y"); var x = vars.get_int("js.kb_x"); 
	var palette = {red: vars.get_int("js.color_red"), green: vars.get_int("js.color_green"), blue: vars.get_int("js.color_blue"),}
	var active_binds = get_active_binds()[0]
	width = lerp(width,get_active_binds()[1], 4 * global_vars.frametime())
	for (var i = 0; i < active_binds.length; i++) {
		if (active_binds[i]){
			count += 1.1
			render.text([x + 5, y + 13 * count], [255, 255, 255, active_binds[i].alpha], 8, 0, active_binds[i].data[1])
			render.text([x + width * 6 + 4, y + 13 * count], [255, 255, 255, active_binds[i].alpha], 8, 0, "[on]")
		}
	}
	switcher = vars.get_int("js.styles_switcher");
	switch (switcher) {
		case 1:
			render.rect([x, y - 10], [(width + 4) * 5.5 + 14, 21], [palette.red, palette.green, palette.blue, 170], 5)
			render.filled_rect([x, y - 10], [(width + 4) * 5.5 + 14, 21], [15, 15, 15, 45], 5)
		break;
		case 2:
			render.rect([x, y - 10], [(width + 4) * 5.5 + 14, 21], [palette.red, palette.green, palette.blue, 170], 20)
			render.filled_rect([x, y - 10], [(width + 4) * 5.5 + 14, 21], [15, 15, 15, 45], 20)
		break;
		case 3:
			render.filled_rect([x, y - 10], [(width + 4) * 5.5 + 14, 21], [15, 15, 15, 75], 0)
		    render.rect([x, y - 10], [(width + 4) * 5.5 + 14, 1], [palette.red, palette.green, palette.blue, 170], 0)
		break;
		default:
			render.rect([x, y - 10], [(width + 4) * 5.5 + 14, 21], [palette.red, palette.green, palette.blue, 170], 0)
		    render.filled_rect([x, y - 10], [(width + 4) * 5.5 + 14, 21], [15, 15, 15, 45], 0)
		break;
	}
	render.text([x +((width + 4) * 5.5 + -28)/2, y + -5], [255, 255, 255, 255], 8, 0, "Keybinds")

	global_alpha = lerp(global_alpha,Math.max(255 * ui.get_menu_alpha(), 255 * Math.min(1, count)), 4 * global_vars.frametime())
   }
})

register_callback("render", function () {
	switcher = vars.get_int("js.styles_switcher");
	var palette = {red: vars.get_int("js.color_red"), green: vars.get_int("js.color_green"), blue: vars.get_int("js.color_blue"),}
	if (vars.get_bool("js.watermark")) {
	switch (switcher) {
	    case 1: 
	        render.rect([1700, 20], [141, 20], [palette.red, palette.green, palette.blue, 170], 5);
	        render.filled_rect([1700, 20], [141, 20], [15, 15, 15, 45], 5)
		break;
		case 2: 
		    render.rect([1700, 20], [141, 20], [palette.red, palette.green, palette.blue, 170], 20); 
	     	render.filled_rect([1700, 20], [141, 20], [15, 15, 15, 45], 20)
	    break;
		case 3:
			render.filled_rect([1700, 20], [140, 20], [15, 15, 15, 75], 0)
			render.rect([1700, 20], [141, 1], [palette.red, palette.green, palette.blue, 170], 0);
		break;
		default:
		    render.rect([1700, 20], [141, 20], [palette.red, palette.green, palette.blue, 170], 0); 
		    render.filled_rect([1700, 20], [141, 20], [15, 15, 15, 45], 0)
		break;
	}
	render.text([1705, 25], [255, 255, 255, 255], 8, 0, "alfonsoware.tk    [alpha] ") // change user here || поменять пользователя тут
	render.text([1725, 24], [palette.red, palette.green, palette.blue, 255], 8, 0, "")
	}
})


register_callback("render", function () {

	const binds = { doubletap: vars.is_bind_active("doubletap"), hide_shots: vars.is_bind_active("hide_shots"), aa_inverter: vars.is_bind_active("inverter")}
	var palette = {red: vars.get_int("js.color_red"), green: vars.get_int("js.color_green"), blue: vars.get_int("js.color_blue"),}
	switcher = vars.get_int("js.inds_styles_switcher");
	if (vars.get_bool("js.indicators")) {
		switch (switcher) {
	case 1:
		render.text([930, 555], binds.aa_inverter ? [255, 255, 255, 255] : [palette.red, palette.green, palette.blue, 255], 8, 0, "alfonso")
		render.text([969, 555], binds.aa_inverter ? [palette.red, palette.green, palette.blue, 255] : [255, 255, 255, 255], 8, 0, "ware")
		render.rect([938, 570], [50, 1], [palette.red, palette.green, palette.blue, 255], 3)
		render.rect([938, 570], [1, 10], [palette.red, palette.green, palette.blue, 255], 3)
		render.rect([987, 570], [1, 10], [palette.red, palette.green, palette.blue, 255], 3)
		render.text([945, 572], binds.doubletap ? [palette.red, palette.green, palette.blue, 255] : [255, 255, 255, 55], 8, 2, "DT")
		render.text([965, 572], binds.hide_shots ? [palette.red, palette.green, palette.blue, 255] : [255, 255, 255, 55], 8, 2, "AA")
	break;
	case 2:
		render.text([941, 555], [255, 255, 255, 255], 8, 2, "alfonso-ware")
	break;
		}
	}
})

register_callback("createmove", function () {  
	if (vars.get_bool("js.animfucker")) {
        var time = 12 * Math["abs"](Math["sin"](64 * global_vars.realtime()));
        if (time > 2) {
            vars.set_bool("misc.slidewalk", false);
        } else {
            vars.set_bool("misc.slidewalk", true);
        }
    }
})

register_callback("player_death", function () {
    if (vars.get_bool("js.trashtalk")) {
        var userid = entity.get_player_for_user_id(current_event.get_int("userid")); 
	    var attacker = entity.get_player_for_user_id(current_event.get_int("attacker"));

        if (attacker == entity.get_local_player() && userid != entity.get_local_player()) {
            for (i in entity.get_enemies()) {
                if (current_event.get_int("hitgroup") == 1) {
                    killsay = KILLSAYS1[math.random_int(0, KILLSAYS2.length)]
                } else {
                    killsay = KILLSAYS1[math.random_int(0, KILLSAYS1.length)]
                }
                cheat.execute_command("say " + killsay)
            }
        }
    }
})


register_callback("createmove", function () {

    var time = parseInt((global_vars.curtime() * 4));

    if (time != lasttime && vars.get_bool("js.clantag")) {

        switch ((time) % 26) {
			case 1: { cheat.set_clantag(" "); break; }
			case 2: { cheat.set_clantag(" "); break; }
            case 3: { cheat.set_clantag("a "); break; }
			case 4: { cheat.set_clantag("al "); break; }
            case 5: { cheat.set_clantag("alf "); break; }
			case 6: { cheat.set_clantag("alfo "); break; }
            case 7: { cheat.set_clantag("alfon "); break; }
			case 8: { cheat.set_clantag("alfons "); break; }
            case 9: { cheat.set_clantag("alfonsow "); break; }
			case 10: { cheat.set_clantag("alfonsowa "); break; }
            case 11: { cheat.set_clantag("alfonsowar "); break; }
			case 12: { cheat.set_clantag("alfonsoware "); break; }
			case 13: { cheat.set_clantag("alfonsoware "); break; }
			case 14: { cheat.set_clantag("alfonsoware "); break; }
            case 15: { cheat.set_clantag("alfonsowar "); break; }
			case 16: { cheat.set_clantag("alfonsowa "); break; }
			case 17: { cheat.set_clantag("alfonsow "); break; }
            case 18: { cheat.set_clantag("alfonso "); break; }
			case 19: { cheat.set_clantag("alfons "); break; }
            case 20: { cheat.set_clantag("alfon "); break; }
			case 21: { cheat.set_clantag("alfo "); break; }
			case 22: { cheat.set_clantag("alf "); break; }
			case 23: { cheat.set_clantag("al "); break; }
            case 24: { cheat.set_clantag("a"); break; }
			case 25: { cheat.set_clantag(" "); break; }
            case 26: { cheat.set_clantag(" "); break; }
		
        }
        lasttime = time;
	}
	if(vars.get_bool("js.clear_tag")) {
	cheat.set_clantag("");
	vars.set_bool("js.clear_tag", false);
	}
})

register_callback("unload", function() {
	utils.play_sound("C:\\Windows\\Media\\Speech Disambiguation.wav");
	convars.set_int("cl_clock_correction", 1);
	convars.set_int("sv_maxusrcmdprocessticks", 16);
	cheat.set_clantag("");
	cheat.log("Till! Soon return!");
})